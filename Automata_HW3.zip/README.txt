
Worked on by
Alexander Vo - ahv160030
Panagiotis Vergos - pxv170003


To run the file, run

python HW3.py "PATH_TO_INPUT_FILE" "PATH_TO_TEST_FILE"

ex: python HW3.py input2.txt testInput2.txt

Tested on Python 3.8.3
